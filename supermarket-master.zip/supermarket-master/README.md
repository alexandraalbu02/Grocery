# supermarket
MEAN Stack project - login details:

Admin example: omri@gmail.com, Passworsd: omri123

Random user example: timothy@gmail.com, Password: timothy123
## Order

![order](https://user-images.githubusercontent.com/37377389/48843035-a0038100-ed9e-11e8-8cfa-6dab5dac44d3.PNG)
## Cart

![cart](https://user-images.githubusercontent.com/37377389/48843050-a98ce900-ed9e-11e8-836c-11782585f372.PNG)
## Edit products

![editproducts](https://user-images.githubusercontent.com/37377389/48843059-b01b6080-ed9e-11e8-81f1-89d6834e287f.PNG)
