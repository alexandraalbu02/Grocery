export interface User {
    _id: string,
    name: string,
    lastName: string,
    username: string,
    password: string,
    city: string,
    street: string,
    role: string
}
