export interface Product {
    _id: string,
    name: string,
    categoryId: string,
    price: string,
    imageUrl: string,
    categoryObj: Array<Object>
}
